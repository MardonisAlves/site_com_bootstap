<?php
include_once("class.conecta.php");//minha conexao

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of class
 *
 * @author DONY
 */
class contato {
    
   protected $tabela;
   protected $con;
   protected $email;
   protected $assunto;
   protected $massage;


   // meodos 
    public function __construct($tabela,$email,$assunto,$message){
        $this->tabela=$tabela;
        $this->email=$email;
        $this->assunto=$assunto;
        $this->massage=$message;
      
    }
    public function cad(){
          $this->con = mysql_query("INSERT INTO $this->tabela (email,assunto,mensagem)VALUE('$this->email','$this->assunto','$this->massage')")or die(mysql_error());  
       if($this->con){
          header('Location: ../index.html');
       }else{
           return FALSE;
       }  
    }
}
$cad = new contato('contato_email',$_POST['email'],$_POST['assunto'],$_POST['message']);
$cad->cad();
?>
