<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of class
 *
 * @author DONY
 */
class conecta {
    public $con = false;
    private $host;
    private $user;
    private $pass;
    private $db;
    
        public function __construct($host,$user,$pass,$db){
        $this->host=$host;
        $this->user=$user;
        $this->pass=$pass;
        $this->db=$db;
        }
        
        public function connexao(){
            
        $this->con = mysql_connect($this->host,  $this->user,  $this->pass) or die(mysql(error));
    if($this->con){
   $this->con=mysql_select_db($this->db);
  
}else{
 die(mysql(error));    
}
    }
}

$con = new conecta('localhost', 'root', '', 'web_system');
$con->connexao();

?>
