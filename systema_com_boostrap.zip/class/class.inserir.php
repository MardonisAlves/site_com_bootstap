<?php
include_once("class.conecta.php");//minha conexao
 /* @author DONY*/


class inserir 
{
    //atributos 
    private $tabela;
    private $con;
    // meodos 
    public function __construct($tabela) {
        $this->tabela=$tabela;
      
    }
    
    public function cad($nome,$resposta,$email){
        $this->con = mysql_query("INSERT INTO $this->tabela (nome,respostas,email)VALUE('$nome','$resposta','$email')")or die(mysql_error());  
       if($this->con){
          header('Location: ../index.html');
       }else{
           return FALSE;
       }
        
    }
    }
$cad = new inserir('resposta');
$cad->cad($_POST['nome'],$_POST['enquete'],$_POST['email']);