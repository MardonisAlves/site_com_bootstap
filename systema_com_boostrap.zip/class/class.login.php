<?php

include 'class.conecta.php';
class  login{
    
    private $tabela;
    private $admin;
    private $senha;
    private $con;
    private $array;




    public function __construct($tabela,$admin,$senha){
        $this->tabela=$tabela;
        $this->admin=$admin;
        $this->senha=$senha;
    }
    

        public function login(){
            
        
        $this->con =  mysql_query('SELECT * FROM admin');
        $this->array = mysql_fetch_array($this->con);
        
        //echo $this->array['admin'];
        //echo $this->array['senha'];
        
        if($this->admin === $this->array['admin'] AND $this->senha === $this->array['senha']){
          session_start();
          $_SESSION['admin'] = $this->array['admin'];
          $_SESSION['senha'] = $this->array['senha'];
        }  else {
            header ('Location: ../index.html');
        }
        
        if(isset($_SESSION['admin'])){
           header ('Location: ../admin.html');
        }else{
       header ('Location: ../index.html');
    }

}
}
$login =  new login('admin',$_POST['admin'],$_POST['senha']);
$login->login();
?>
