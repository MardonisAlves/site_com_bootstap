-- Gera��o de Modelo f�sico
-- Sql ANSI 2003 - brModelo.



CREATE TABLE Contato_email (
email VARCHAR(100),
assunto VARCHAR(50),
mensagem VARCHAR(200),
Id_contato INTEGER PRIMARY KEY
)

